package com.city.citylist.model;

import java.io.Serializable;

public class Photo implements Serializable {
    public String url;
}
