package com.city.citylist.model;

public class Price {
    public int day;
    public int hour;
    public int night;
}
