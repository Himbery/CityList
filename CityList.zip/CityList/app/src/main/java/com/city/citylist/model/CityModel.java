package com.city.citylist.model;

public class CityModel {
    public String name;
    public int id;
    public Coordinates coordinates;
}
