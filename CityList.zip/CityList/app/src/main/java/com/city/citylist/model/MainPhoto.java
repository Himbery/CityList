package com.city.citylist.model;

public class MainPhoto {
    public String url;
}
