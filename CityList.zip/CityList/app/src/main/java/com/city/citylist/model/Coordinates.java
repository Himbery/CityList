package com.city.citylist.model;

public class Coordinates {
    public double lon;
    public double lat;
}
