package com.city.citylist.model;

import java.util.List;

public class FlatsListModel {
    public List<AppartmentModel> flats;
}
