package com.city.citylist.model;

import java.util.List;

public class CountryModel {
    public int id;
    public String name;
    public List<CityModel> cities;
}
