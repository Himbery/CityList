package com.city.citylist.model;

import java.util.List;

public class AppartmentModel {
    public MainPhoto photo_default;
    public String address;
    public String description;
    public Price prices;
    public String building_type;
    public String title;
    public List<Photo> photos;

}
