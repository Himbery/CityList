package com.city.citylist;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import com.city.citylist.model.AppartmentModel;
import com.city.citylist.model.FlatsListModel;
import com.city.citylist.service.CityAdapter;
import com.city.citylist.service.MyApi;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    RecyclerView cityList;
    CityAdapter cityAdapter;
    List<AppartmentModel> cities = new ArrayList<>();
    SharedPreferences preferences;
    int city_id, country_id;
    int width, height;
    String cityName;
    TextView nameCity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        preferences = getSharedPreferences("DATA", MODE_PRIVATE);
        city_id = preferences.getInt("city_id", 0);
        country_id = preferences.getInt("country_id", 0);
        cityName = preferences.getString("city_name", "");
        width = 200;
        height = 150;
        nameCity = (TextView) findViewById(R.id.name_city);
//        nameCity.setText(cityName);
        cityList = (RecyclerView) findViewById(R.id.city_list);
        cityList.setLayoutManager(new LinearLayoutManager(this));

        getCities(city_id, width, height, country_id);

    }
    public void getCities(int id, int id2, int height, int width){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.beta.kvartirka.pro/")
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .build();
        MyApi api = retrofit.create(MyApi.class);

        Call<FlatsListModel> call = api.appart(id, id2, height, width);
        call.enqueue(new Callback<FlatsListModel>() {
            @Override
            public void onResponse(Call<FlatsListModel> call, Response<FlatsListModel> response) {
                FlatsListModel flatsListModel = response.body();
                List<AppartmentModel> appartmentModels = flatsListModel.flats;

                cityAdapter = new CityAdapter(MainActivity.this, appartmentModels);
                cityList.setAdapter(cityAdapter);
                cityAdapter.notifyDataSetChanged();
                nameCity.setText(cityName);
            }

            @Override
            public void onFailure(Call<FlatsListModel> call, Throwable t) {

            }
        });
    }
}
