package com.city.citylist.model;

import java.util.List;

public class DataItem {
    public List<CountryModel> countries;
    public double version;
}
