package com.city.citylist;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.telephony.TelephonyManager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.city.citylist.model.CityModel;
import com.city.citylist.model.Coordinates;
import com.city.citylist.model.CountryModel;
import com.city.citylist.model.DataItem;
import com.city.citylist.service.MyApi;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

public class SplashActivity extends AppCompatActivity {
    String CountryID;
    String cID;
    int countryID;
    private LocationManager locationManager;
    SharedPreferences preferences;
    double locationLat;
    double locationLon;
    int idCity;
    String city;
    Location currentLocation;
    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 777;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash);

        int permissionStatus = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION);

        if (permissionStatus == PackageManager.PERMISSION_GRANTED) {
            preferences = getSharedPreferences("DATA", MODE_PRIVATE);
            locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        } else {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.ACCESS_FINE_LOCATION},
                    MY_PERMISSIONS_REQUEST_LOCATION);
        }


        preferences = getSharedPreferences("DATA", MODE_PRIVATE);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

       idCity = preferences.getInt("city_id", 0);
        if (idCity != 0){
            Intent intent = new Intent(SplashActivity.this, MainActivity.class);
            startActivity(intent);
            finish();

        }


    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    idCity = preferences.getInt("city_id", 0);
                    if (idCity != 0){
                        Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                        startActivity(intent);
                        finish();

                    }
                } else {
                    preferences = getSharedPreferences("DATA", MODE_PRIVATE);
                }
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            return;
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 100, locationListener);
        locationManager.requestLocationUpdates(
                LocationManager.NETWORK_PROVIDER, 0, 100, locationListener);
    }

    @Override
    protected void onPause() {
        super.onPause();
        locationManager.removeUpdates(locationListener);
    }


    public void getData() {
        countryID = getCountryZipCode();
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt("country_id", countryID);
        editor.apply();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.beta.kvartirka.pro/")
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .build();
        MyApi api = retrofit.create(MyApi.class);

        Call<DataItem> call = api.call();
        call.enqueue(new Callback<DataItem>() {
            @Override
            public void onResponse(Call<DataItem> call, Response<DataItem> response) {
                DataItem item = response.body();
                List<CountryModel> countries = item.countries;
                double v = item.version;

                Float minDistance = null;
                CityModel closestCity = null;

                for (int index = 0; index < countries.size(); index++) {
                    if (countries.get(index).id == countryID) {

                        List<CityModel> cities = countries.get(index).cities;

                        for (int i = 0; i < cities.size(); i++) {
                            CityModel city = cities.get(i);
                            Coordinates coordinates = city.coordinates;
                            Location cityLocation = new Location("locationA");
                            cityLocation.setLatitude(city.coordinates.lat);
                            cityLocation.setLongitude(city.coordinates.lon);

                            float distance = currentLocation.distanceTo(cityLocation);

                            if (minDistance == null || distance < minDistance) {
                                minDistance = distance;
                                closestCity = city;

                            }
                        }
                    }
                }

                idCity = closestCity.id;
                city = closestCity.name;

                if (idCity == 0){
                    idCity = 18;
                    city = "Москва";
                }

                SharedPreferences.Editor editor = preferences.edit();
                editor.putInt("city_id", idCity);
                editor.putString("city_name", city);
                editor.apply();

                Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }

            @Override
            public void onFailure(Call<DataItem> call, Throwable t) {

            }
        });

    }

    private int getCountryZipCode() {
        TelephonyManager manager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        CountryID = manager.getSimCountryIso().toUpperCase();

        switch (CountryID) {
            case "RU":
                return 643;
            case "BY":
                return 112;
            case "KZ":
                return 398;
            case "UA":
                return 804;
            case "AB":
                return 805;
            case "MD":
                return 806;
            case "KG":
                return 807;
            case "CZ":
                return 808;
            case "AZ":
                return 809;
            case "AM":
                return 810;
            case "HU":
                return 811;
            case "EE":
                return 812;
            case "LV":
                return 813;
            case "LT":
                return 814;
            case "GE":
                return 815;
            case "FI":
                return 816;
            case "ME":
                return 817;
            case "BG":
                return 818;
            case "UZ":
                return 824;
            case "TR":
                return 822;
            case "GR":
                return 819;
            case "RS":
                return 821;
            case "CY":
                return 881;
            case "DE":
                return 901;
            case "IL":
                return 926;
            case "IT":
                return 927;
            case "PL":
                return 987;
            case "ES":
                return 1018;

        }
        return 0;
    }


    public LocationListener locationListener = new LocationListener() {

        @Override
        public void onLocationChanged(Location location) {
            currentLocation = location;
            getData();
        }

        @Override
        public void onProviderDisabled(String provider) {
        }

        @SuppressLint("MissingPermission")
        @Override
        public void onProviderEnabled(String provider) {
            showLocation(locationManager.getLastKnownLocation(provider));
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
            if (provider.equals(LocationManager.GPS_PROVIDER)) {

            } else if (provider.equals(LocationManager.NETWORK_PROVIDER)) {

            }
        }
    };

    private void showLocation(Location location) {
        if (location == null)
            return;
        if (location.getProvider().equals(LocationManager.GPS_PROVIDER)) {
            currentLocation = new Location("locationB");
            locationLat = location.getLatitude();
            locationLon = location.getLongitude();
            currentLocation.setLatitude(locationLat);
            currentLocation.setLongitude(locationLon);

        }
        else if (location.getProvider().equals(LocationManager.NETWORK_PROVIDER)) {
            currentLocation = new Location("locationB");
            locationLat = location.getLatitude();
            locationLon = location.getLongitude();
            currentLocation.setLatitude(locationLat);
            currentLocation.setLongitude(locationLon);

        }
    }
}
